import sys
import re
from io import open


def partition(lst2, low, high):
    x = (low - 1)
    pivot = lst2[high]  # pivot

    for j in range(low, high):

        if lst2[j] < pivot:
            x = x + 1
            lst2[x], lst2[j] = lst2[j], lst2[x]

    lst2[x + 1], lst2[high] = lst2[high], lst2[x + 1]
    return x + 1


# Function to do Quick sort
def quick_sort(lst2, low, high):
    if low < high:
        pi = partition(lst2, low, high)
        quick_sort(lst2, low, pi - 1)
        quick_sort(lst2, pi + 1, high)


def exp(n, m):
    # 0^m
    if n == 0:
        return 0
    # n^0
    elif m == 0:
        return 1
    # 1^m
    elif n == 1:
        return n
    else:
        return n * exp(n, m - 1)


def fact(n):
    if n <= 0:
        return 1
    else:
        return n * fact(n - 1)


def fib(n):
    if n == 0:
        return 0
    elif n == 1:
        return 1
    else:
        return fib(n - 1) + fib(n - 2)


# Command Draw Triangle
def draw_triangle_asc(n):
    character = '*'
    if n > 0:
        draw_triangle_asc(n-1)
        print(character*n)


def draw_triangle_dsc(n):
    character = '*'
    if n > 0:
        print(character * n)
        draw_triangle_dsc(n-1)


# Command Draw Rhombus
def draw_rhombus(n):
    for height in range(1, n):
        for space in range(1, n-height):
            print(" ", end="")
        for symbol in range(1, (height*2)-1):
            print('*', end="")
        print("")

    for height in range(1, n):
        for space in range(1, n-height):
            print(" ", end="")
        for symbol in range(1, (height*2)-1):
            print('*', end="")
        print("")


# Command Sum
def add(arr, size):
    if size == 0:
        return 0
    else:
        return arr[size-1] + add(arr, size-1)


def ack(n, m):
    if n == 0:
        return m + 1
    elif m == 0:
        return ack(n-1, 1)
    else:
        return ack(n-1, ack(n, m-1))


def main():
    # Information
    print("")
    print('************Recursive Calc**************')
    print('Developed by Javier Alvarez')
    print('201807374\n')
    while True:
        print(">> ", end="")
        command = input()
        while command is None:
            print('Invalid Command')
            print(">> ", end="")
            command = input()
            command = command.lower()
        else:
            if command.lower() == 'exit':
                sys.exit()
            else:
                analyse_command(command.strip())


def analyse_command(command):
    command.lower()

    if 'solve' in command:
        ex = command.replace('solve', '')
        ex = ex.replace("[", "").replace("]", "")
        ex = ex.replace(" ", "")

        pattern = "[0-9]*[.]?[0-9]+|[a-z]+[(][^)]+[)]"
        operands = re.findall(pattern, ex)
        operators = re.sub(pattern, '', ex)

        print("")
        print("Solving: ", end="")
        print(ex)
        print("Result: ", end="")
        evaluate(operands, operators)

    elif 'sort' in command:
        ex = command.replace('sort', '')
        ex = ex.replace("[", "").replace("]", "")
        ex = ex.replace("--type=", "")
        ex = ex.replace(",", " ")

        pattern = "[-]*[0-9]*[.]?[0-9]"
        pattern2 = "[a-z]+|[asc]+[desc]"

        expression = re.findall(pattern, ex)
        types = re.findall(pattern2, ex)

        lst = expression
        lst2 = lst
        for a in range(0, len(lst)):
            data = float(expression[a])
            lst2[a] = data
            # print(lst2[a])
        print("")
        print("     ----------Sorting----------")
        print(lst2)
        if 'asc' in types:
            num = len(lst2)
            quick_sort(lst2, 0, num - 1)
            print("")
            print("     --------Sorted array-------")
            for i in range(num):
                print("%d" % lst2[i], end=" ")
            print('')
        elif 'desc' in types:
            num = len(lst2)
            quick_sort(lst2, 0, num - 1)
            print("")
            print("     --------Sorted array-------")
            lst2.reverse()
            for i in range(num):
                print("%d" % lst2[i], end=" ")
            print('')
        else:
            print('Type Unknown, Check Type')

    elif 'sum' in command:
        ex = command.replace('sum', '')
        ex = ex.replace("[", "").replace("]", "")
        ex = ex.replace(" ", "")

        pattern = "[-]*[0-9]*[.]?[0-9]"

        expression = re.findall(pattern, ex)
        lst = expression
        lst2 = lst

        print("")
        print("Adding: ", end="")
        print(expression)
        print('Result: ', end="")

        for a in range(0, len(lst)):
            data = float(expression[a])
            lst2[a] = data
        print(add(lst2, len(lst2)))

    elif 'drawTriangle' in command:
        ex = command.replace('drawTriangle', '')
        ex = ex.replace("--type=", "").replace("--length=", "")
        # ex = ex.replace(",", " ")

        pattern = "[a-z]+|[asc]+[dsc]"
        pattern1 = "[0-9]+"

        types = re.findall(pattern, ex)
        length = re.findall(pattern1, ex)
        # print(types)
        # print(length)
        val = int(length[0])
        print("")
        print("Drawing Triangle")
        print('Size: ' + str(val))
        print("")
        if "asc" in types:
            draw_triangle_asc(val)

        elif "desc" in types:
            draw_triangle_dsc(val)
        else:
            print("INSERT A LENGTH GREATER THAN 1")

    elif 'drawRhombus' in command:
        ex = command.replace('drawRhombus', '')
        ex = ex.replace("--size=", "")
        ex = ex.replace(" ", "")

        pattern = "[0-9]+"

        size = re.findall(pattern, ex)
        val = int(size[0])
        print("")
        print("Drawing Rhombus")
        if val > 1:
            draw_rhombus(val)
        else:
            print('INSERT A VALUE GREATER THAN 1')

    elif 'exec' in command:
        # exec --file =”instructions.calc”
        ex = command.replace('exec', '')
        ex = ex.replace("--file =", "")
        ex = ex.replace(' ', '')

        pattern = "[a-z]+[.]+[a-z]+"

        path = re.findall(pattern, ex)

        execute(path[0])


def evaluate(operands, operators):

    for operator in operators:

        op1 = evaluate_functions(str(operands.pop(0)))
        op2 = evaluate_functions(str(operands.pop(0)))

        if operator == '+':
            operands.insert(0, op1 + op2)
        elif operator == '-':
            operands.insert(0, op1 - op2)
        elif operator == '*':
            operands.insert(0, op1 * op2)
        elif operator == '/':
            operands.insert(0, op1 / op2)
        elif operator == '^':
            operands.insert(0, op1 ^ op2)
        else:
            print("Operator not recognized")

    print(operands[0])


def evaluate_functions(expression):

    if "exp" in expression.lower():
        expression = expression.lower().replace("exp", "")
        expression = expression.replace("(", "").replace(")", "")

        pattern = "[0-9]+"

        data = re.findall(pattern, expression)
        # print(data)
        n = int(data[0])
        m = int(data[1])
        return exp(n, m)

    elif "fact" in expression.lower():
        expression = expression.lower().replace("fact", "")
        expression = expression.replace("(", "").replace(")", "")

        return fact(int(expression))

    elif "fib" in expression.lower():
        expression = expression.lower().replace("fib", "")
        expression = expression.replace("(", "").replace(")", "")

        return fib(int(expression))

    elif "ack" in expression.lower():
        expression = expression.lower().replace("ack", "")
        expression = expression.replace("(", "").replace(")", "")

        pattern = "[0-9]+"

        data = re.findall(pattern, expression)
        # print(data)
        m = int(data[0])
        n = int(data[1])
        return ack(m, n)

    return float(expression)


def execute(path):
    print(path)

    print("Opening File")
    print('...')
    # Opening the File
    file = open(path, "r")
    lines = []

    print("Reading File")
    print("...")
    for line in file:
        # print(line.rstrip('\n'))
        lines.append(line.rstrip('\n'))
    file.close()
    for i in range(len(lines)):
        analyse_command(str(lines[i]))


# print(evaluate_functions('exp(2,3)'))

execute("instructions.calc")

main()


